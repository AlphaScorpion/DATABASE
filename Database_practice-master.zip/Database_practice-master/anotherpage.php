<?php
	/*include 'header.php';
	if(isset($_POST['submit']))
	{
		echo 'Process 2';
	}*/

	echo $_SERVER['HTTP_HOST'];
?>