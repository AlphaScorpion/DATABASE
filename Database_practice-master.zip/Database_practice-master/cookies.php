<?php

	//echo $time = time();
	setcookie('name','alex',time()+10);	//to set the cookie
//	setcookie('name','alex',time()-10); //to unset the cookie


?>