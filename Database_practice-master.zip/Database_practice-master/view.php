<?php
	/*session_start();
	//echo $_SESSION['name'];
	if(isset($_SESSION['name']) && isset($_SESSION['age']))
	{
		echo 'Welcome '.$_SESSION['name']  .  $_SESSION['age'];
	}
	else
	{
		echo 'please log in';
	}*/

	echo $_COOKIE['name'];


?>