<?php

include 'count.php';
hit_count();

?>