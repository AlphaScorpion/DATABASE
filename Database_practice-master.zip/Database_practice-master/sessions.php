<?php
session_start();
$_SESSION['name'] = 'Alex';
$_SESSION['age'] = '21';

?>