<?php
	
	session_start();

	//unset($_SESSION['name']);
	//if you want to destroy all sessions
	session_destroy();
?>